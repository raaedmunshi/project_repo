# 500-WC > 2023-03-07 10:11am
https://universe.roboflow.com/mdmj/500-wc

Provided by a Roboflow user
License: CC BY 4.0

